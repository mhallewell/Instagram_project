var config = {}

 config.client_id	= '06c2b75726564d68ab9b8ed76e103f0a'
 config.client_secret	= '666ce29471e54df0b31f834dbcdaad48'
 config.redirect_uri	= 'http://127.0.0.1:3000/auth/finalize'

 module.exports = config 
